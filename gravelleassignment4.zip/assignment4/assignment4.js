let cix = 10
let ciy = 10
function setup(){
	createCanvas(400,400);
	background(50);
	frameRate(30);
}
function draw(){
	colorMode(RGB,200);
	let t=3;
	while(t>0){
		print("Move in "+t);
		t = t-1;
	}
	ellipse(cix,ciy, 10);
	rect(370,10,20,20,20);
	if (keyIsPressed == true){
		cix = cix+5;
	}
	//if x off screen turn corner red
	if (cix < 405){
	fill(20, 150, 20);
	}else{
	fill(150, 20, 20);
	}
	//if y off screen turn corner red
	if (ciy > 405){
	fill(150, 20, 20);
	}
	//stop stuff from going on forever
	if (cix > 420){
	print("No more moves.")
	noLoop();
	}
	if (ciy > 420){
	print("No more moves.")
	noLoop();
	}
}
function mouseClicked(){
		ciy= ciy+5;
	}
