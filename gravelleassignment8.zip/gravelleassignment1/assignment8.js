var img;
var limit;
var bug;
var words = "i am at my limit";
var wordy = "yeah yeah yeah";
var fancy = "girl help me";
function preload(){
	img = loadImage("827.png");
	limit = loadImage("limit.jpg");
	bug = loadImage("insect.png");
}
function setup(){
	createCanvas(800,800);
}
function draw(){
	createCanvas(800,800);
	image(img,0,0,100,100);
	image(limit,0,100,300,300);
	image(bug, mouseX,mouseY,50,50);
	fill(0);
	textSize(25);
	textFont('Georgia');
	text(words,100,0,200,200);
	textFont('New Tegomin');
	textSize(18);
	stroke(8);
	fill(120);
	text(wordy,90,200,200);

}
	